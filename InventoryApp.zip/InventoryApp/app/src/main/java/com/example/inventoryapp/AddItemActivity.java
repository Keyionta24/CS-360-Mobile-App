package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    EditText etItemName, etQuantity, etCategory;
    Button btnSaveItem, btnCancelAdd;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        etItemName = findViewById(R.id.etItemName);
        etQuantity = findViewById(R.id.etQuantity);
        etCategory = findViewById(R.id.etCategory);
        btnSaveItem = findViewById(R.id.btnSaveItem);
        btnCancelAdd = findViewById(R.id.btnCancelAdd);

        databaseHelper = new DatabaseHelper(this);

        btnSaveItem.setOnClickListener(v -> saveItem());

        btnCancelAdd.setOnClickListener(v -> {
            Intent intent = new Intent(AddItemActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void saveItem() {
        String itemName = etItemName.getText().toString().trim();
        String quantityText = etQuantity.getText().toString().trim();
        String category = etCategory.getText().toString().trim();

        if (itemName.isEmpty() || quantityText.isEmpty() || category.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(quantityText);

        boolean inserted = databaseHelper.addItem(itemName, quantity, category);

        if (inserted) {
            Toast.makeText(this, "Item saved successfully!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(AddItemActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Failed to save item.", Toast.LENGTH_SHORT).show();
        }
    }
}