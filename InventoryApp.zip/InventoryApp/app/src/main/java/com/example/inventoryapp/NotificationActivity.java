package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class NotificationActivity extends AppCompatActivity {

    Button btnRequestPermission, btnSavePhone, btnBackToInventory;
    TextView tvPermissionStatus;
    EditText etPhoneNumber;

    SharedPreferences sharedPreferences;

    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    tvPermissionStatus.setText("SMS permission granted. Alerts can be sent when inventory reaches zero.");
                } else {
                    tvPermissionStatus.setText("SMS permission denied. The app will still work, but text alerts are off.");
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        btnRequestPermission = findViewById(R.id.btnRequestPermission);
        btnSavePhone = findViewById(R.id.btnSavePhone);
        btnBackToInventory = findViewById(R.id.btnBackToInventory);
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);

        sharedPreferences = getSharedPreferences("InventoryPrefs", MODE_PRIVATE);

        loadSavedPhoneNumber();
        checkPermissionStatus();

        btnRequestPermission.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {
                tvPermissionStatus.setText("SMS permission already granted. Alerts are enabled.");
            } else {
                requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        btnSavePhone.setOnClickListener(v -> savePhoneNumber());

        btnBackToInventory.setOnClickListener(v -> {
            Intent intent = new Intent(NotificationActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void checkPermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            tvPermissionStatus.setText("SMS permission already granted. Alerts are enabled.");
        } else {
            tvPermissionStatus.setText("SMS permission not granted yet.");
        }
    }

    private void savePhoneNumber() {
        String phoneNumber = etPhoneNumber.getText().toString().trim();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("alert_phone", phoneNumber);
        editor.apply();

        Toast.makeText(this, "Phone number saved.", Toast.LENGTH_SHORT).show();
    }

    private void loadSavedPhoneNumber() {
        String savedPhone = sharedPreferences.getString("alert_phone", "");
        etPhoneNumber.setText(savedPhone);
    }
}