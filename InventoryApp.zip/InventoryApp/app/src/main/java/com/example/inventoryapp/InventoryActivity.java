package com.example.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    Button btnAddItem, btnLogout, btnNotifications;
    TableLayout tableInventory;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        btnAddItem = findViewById(R.id.btnAddItem);
        btnLogout = findViewById(R.id.btnLogout);
        btnNotifications = findViewById(R.id.btnNotifications);
        tableInventory = findViewById(R.id.tableInventory);

        databaseHelper = new DatabaseHelper(this);

        btnAddItem.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

        btnNotifications.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, NotificationActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInventoryItems();
    }

    private void loadInventoryItems() {
        // Keep the header row only
        if (tableInventory.getChildCount() > 1) {
            tableInventory.removeViews(1, tableInventory.getChildCount() - 1);
        }

        Cursor cursor = databaseHelper.getAllItems();

        if (cursor.moveToFirst()) {
            do {
                int itemId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QUANTITY));

                addTableRow(itemId, itemName, quantity);

            } while (cursor.moveToNext());
        } else {
            TableRow emptyRow = new TableRow(this);

            TextView emptyText = new TextView(this);
            emptyText.setText("No items added yet.");
            emptyText.setPadding(8, 8, 8, 8);

            emptyRow.addView(emptyText);
            tableInventory.addView(emptyRow);
        }

        cursor.close();
    }

    private void addTableRow(int itemId, String itemName, int quantity) {
        TableRow row = new TableRow(this);

        TextView tvName = new TextView(this);
        tvName.setText(itemName);
        tvName.setPadding(8, 8, 8, 8);

        TextView tvQty = new TextView(this);
        tvQty.setText(String.valueOf(quantity));
        tvQty.setPadding(8, 8, 8, 8);

        Button btnEdit = new Button(this);
        btnEdit.setText("Edit");
        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, EditItemActivity.class);
            intent.putExtra("item_id", itemId);
            startActivity(intent);
        });

        Button btnDelete = new Button(this);
        btnDelete.setText("Delete");
        btnDelete.setOnClickListener(v -> deleteItem(itemId));

        row.addView(tvName);
        row.addView(tvQty);
        row.addView(btnEdit);
        row.addView(btnDelete);

        tableInventory.addView(row);
    }

    private void deleteItem(int itemId) {
        boolean deleted = databaseHelper.deleteItem(itemId);

        if (deleted) {
            Toast.makeText(this, "Item deleted successfully!", Toast.LENGTH_SHORT).show();
            loadInventoryItems();
        } else {
            Toast.makeText(this, "Failed to delete item.", Toast.LENGTH_SHORT).show();
        }
    }
}