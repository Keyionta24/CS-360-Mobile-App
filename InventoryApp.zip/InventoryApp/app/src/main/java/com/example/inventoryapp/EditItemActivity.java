package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class EditItemActivity extends AppCompatActivity {

    Button btnIncrease, btnDecrease, btnSaveEdit, btnDeleteItem, btnCancelEdit;
    EditText etEditItemName, etEditQuantity, etEditCategory;

    DatabaseHelper databaseHelper;
    int itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        btnIncrease = findViewById(R.id.btnIncrease);
        btnDecrease = findViewById(R.id.btnDecrease);
        btnSaveEdit = findViewById(R.id.btnSaveEdit);
        btnDeleteItem = findViewById(R.id.btnDeleteItem);
        btnCancelEdit = findViewById(R.id.btnCancelEdit);

        etEditItemName = findViewById(R.id.etEditItemName);
        etEditQuantity = findViewById(R.id.etEditQuantity);
        etEditCategory = findViewById(R.id.etEditCategory);

        databaseHelper = new DatabaseHelper(this);

        itemId = getIntent().getIntExtra("item_id", -1);

        if (itemId == -1) {
            Toast.makeText(this, "Item not found.", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadItemData();

        btnIncrease.setOnClickListener(v -> {
            String qtyText = etEditQuantity.getText().toString().trim();
            int qty = qtyText.isEmpty() ? 0 : Integer.parseInt(qtyText);
            qty++;
            etEditQuantity.setText(String.valueOf(qty));
        });

        btnDecrease.setOnClickListener(v -> {
            String qtyText = etEditQuantity.getText().toString().trim();
            int qty = qtyText.isEmpty() ? 0 : Integer.parseInt(qtyText);

            if (qty > 0) {
                qty--;
            }

            etEditQuantity.setText(String.valueOf(qty));
        });

        btnSaveEdit.setOnClickListener(v -> saveChanges());

        btnDeleteItem.setOnClickListener(v -> deleteItem());

        btnCancelEdit.setOnClickListener(v -> {
            Intent intent = new Intent(EditItemActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void loadItemData() {
        Cursor cursor = databaseHelper.getItemById(itemId);

        if (cursor.moveToFirst()) {
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QUANTITY));
            String category = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_CATEGORY));

            etEditItemName.setText(itemName);
            etEditQuantity.setText(String.valueOf(quantity));
            etEditCategory.setText(category);
        } else {
            Toast.makeText(this, "Unable to load item.", Toast.LENGTH_SHORT).show();
            finish();
        }

        cursor.close();
    }

    private void saveChanges() {
        String itemName = etEditItemName.getText().toString().trim();
        String quantityText = etEditQuantity.getText().toString().trim();
        String category = etEditCategory.getText().toString().trim();

        if (itemName.isEmpty() || quantityText.isEmpty() || category.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(quantityText);

        boolean updated = databaseHelper.updateItem(itemId, itemName, quantity, category);

        if (updated) {
            if (quantity == 0) {
                sendLowInventorySms(itemName);
            }

            Toast.makeText(this, "Changes saved successfully!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(EditItemActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Failed to save changes.", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteItem() {
        boolean deleted = databaseHelper.deleteItem(itemId);

        if (deleted) {
            Toast.makeText(this, "Item deleted successfully!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(EditItemActivity.this, InventoryActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Failed to delete item.", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendLowInventorySms(String itemName) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        SharedPreferences sharedPreferences = getSharedPreferences("InventoryPrefs", MODE_PRIVATE);
        String phoneNumber = sharedPreferences.getString("alert_phone", "");

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "No phone number saved for alerts.", Toast.LENGTH_SHORT).show();
            return;
        }

        String message = "Inventory alert: " + itemName + " has reached quantity 0.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS alert sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
        }
    }
}