package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etUsername, etPassword;
    Button btnLogin, btnCreateAccount;
    TextView tvError;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);
        tvError = findViewById(R.id.tvError);

        databaseHelper = new DatabaseHelper(this);

        btnLogin.setOnClickListener(v -> loginUser());
        btnCreateAccount.setOnClickListener(v -> createAccount());
    }

    private void loginUser() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        tvError.setVisibility(View.GONE);

        if (username.isEmpty() || password.isEmpty()) {
            tvError.setText("Please enter username and password.");
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        boolean validUser = databaseHelper.checkUser(username, password);

        if (validUser) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);
        } else {
            tvError.setText("Invalid username or password.");
            tvError.setVisibility(View.VISIBLE);
        }
    }

    private void createAccount() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        tvError.setVisibility(View.GONE);

        if (username.isEmpty() || password.isEmpty()) {
            tvError.setText("Please enter username and password.");
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        if (databaseHelper.userExists(username)) {
            tvError.setText("Username already exists.");
            tvError.setVisibility(View.VISIBLE);
            return;
        }

        boolean inserted = databaseHelper.addUser(username, password);

        if (inserted) {
            Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);
        } else {
            tvError.setText("Account creation failed.");
            tvError.setVisibility(View.VISIBLE);
        }
    }
}